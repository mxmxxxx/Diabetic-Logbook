SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for daydata
-- ----------------------------
DROP TABLE IF EXISTS `daydata`;
CREATE TABLE `daydata`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `userId` bigint NULL DEFAULT NULL COMMENT 'user id who created',
  `createTime` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'creation time',
  `updateTime` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'update time',
  `isDelete` tinyint NULL DEFAULT 0 COMMENT 'whether deleted',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = 'post' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of daydata
-- ----------------------------
INSERT INTO `daydata` VALUES (4, '100mg/dL', 2, '2023-12-22 14:04:35', '2023-12-22 14:04:35', 0, 'blood sugar');
INSERT INTO `daydata` VALUES (5, '120mg/dL', 2, '2023-12-22 14:08:49', '2023-12-22 14:08:49', 0, 'blood sugar');
INSERT INTO `daydata` VALUES (7, '80mg/dL', 2, '2023-12-21 14:57:06', '2023-12-22 14:57:23', 0, 'blood sugar');
INSERT INTO `daydata` VALUES (8, '143mg/dL', 1, '2023-12-22 15:26:21', '2023-12-22 15:26:21', 0, 'blood sugar');
INSERT INTO `daydata` VALUES (9, '50mg/dL', 1, '2023-12-22 15:27:15', '2023-12-22 15:27:15', 0, 'blood sugar');
INSERT INTO `daydata` VALUES (10, '100mg/dL', 1, '2023-12-14 15:27:21', '2023-12-22 15:28:17', 0, 'blood sugar');

-- ----------------------------
-- Table structure for post
-- ----------------------------
DROP TABLE IF EXISTS `post`;
CREATE TABLE `post`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT 'content',
  `userId` bigint NULL DEFAULT NULL COMMENT 'user id who created',
  `createTime` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'creation time',
  `updateTime` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'update time',
  `isDelete` tinyint NULL DEFAULT 0 COMMENT 'whether deleted',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = 'post' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of post
-- ----------------------------
INSERT INTO `post` VALUES (1, 'Go to class to learn JAVA', 1, '2023-12-22 00:17:14', '2023-12-22 15:04:51', 0, 'Learn');
INSERT INTO `post` VALUES (2, 'record blood sugar at 8 PM', 1, '2023-12-22 12:56:08', '2023-12-22 15:05:07', 0, 'take record');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `userName` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT 'user nickname',
  `userAccount` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'account',
  `userAvatar` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT 'user avatar',
  `gender` tinyint NULL DEFAULT NULL COMMENT 'gender',
  `userRole` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'user' COMMENT 'user role: user / admin',
  `userPassword` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'password',
  `createTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'creation time',
  `updateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'update time',
  `isDelete` tinyint NOT NULL DEFAULT 0 COMMENT 'whether deleted',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uni_userAccount`(`userAccount` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = 'user' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, NULL, 'admin', NULL, NULL, 'user', '71b0ff231d76118d6327e217d76ad934', '2023-12-21 13:35:18', '2023-12-21 13:35:18', 0);
INSERT INTO `user` VALUES (2, NULL, 'ceshi', NULL, NULL, 'user', '71b0ff231d76118d6327e217d76ad934', '2023-12-22 13:06:34', '2023-12-22 13:06:34', 0);

SET FOREIGN_KEY_CHECKS = 1;
