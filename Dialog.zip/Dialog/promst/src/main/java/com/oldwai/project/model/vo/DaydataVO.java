package com.oldwai.project.model.vo;

import com.oldwai.project.model.entity.Daydata;
import com.oldwai.project.model.entity.Post;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 视图
 *
 * @author oldwai
 * @TableName product
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class DaydataVO extends Daydata {


    private static final long serialVersionUID = 1L;
}