package com.oldwai.project.model.dto.daydata;

import lombok.Data;

import java.io.Serializable;

@Data
public class DaydataDoThumbRequest implements Serializable {

    /**
     *  id
     */
    private long postId;

    private static final long serialVersionUID = 1L;
}