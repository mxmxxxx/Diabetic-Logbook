package com.oldwai.project.model.dto.post;

import lombok.Data;

import java.io.Serializable;

/**
 * 更新请求
 *
 * @TableName product
 */
@Data
public class PostUpdateRequest implements Serializable {

    /**
     * id
     */
    private long id;

    /**
     * 内容
     */
    private String content;

    /**
     * 标题
     */
    private String title;

    private static final long serialVersionUID = 1L;
}