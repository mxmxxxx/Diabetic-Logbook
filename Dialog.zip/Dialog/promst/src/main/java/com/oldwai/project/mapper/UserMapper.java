package com.oldwai.project.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.oldwai.project.model.entity.User;

/**
 * @Entity com.oldwai.project.model.domain.User
 */
public interface UserMapper extends BaseMapper<User> {

}




